
class Game:

    def __init__(self):
        pass

    def make_move(self, column):
        pass

    def get_winner(self):
       pass

    def get_player_at(self, row, col):
        pass

    def get_current_player(self):
        pass
