
class AI:

    def __init__(self, game, player):
        pass

    def find_legal_move(self, timeout=None):
        pass

    def get_last_found_move(self):
        pass
